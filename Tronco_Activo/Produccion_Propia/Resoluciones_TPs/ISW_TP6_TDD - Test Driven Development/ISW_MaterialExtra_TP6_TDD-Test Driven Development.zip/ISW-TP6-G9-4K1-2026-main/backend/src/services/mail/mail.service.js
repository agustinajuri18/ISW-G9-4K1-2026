
const fs = require("fs");
const path = require("path");
const Handlebars = require("handlebars");
const nodemailer = require("nodemailer");

// Leer la plantilla HTML desde un archivo externo
const rutaPlantilla = path.join(__dirname, "confirmacionCompra.hbs");

const plantilla = fs.readFileSync(rutaPlantilla, "utf8");

// Compilar la plantilla una sola vez
const plantillaCompilada = Handlebars.compile(plantilla);

function formatearFecha(fecha) {
    if (!fecha) return "";

    const [anio, mes, dia] = fecha.split("-");

    return `${dia}/${mes}/${anio}`;
}

function formatearTiposPase(tiposPase) {
    return (tiposPase ?? [])
        .map(tipo => tipo === "REGULAR" ? "Regular" : tipo)
        .join(", ");
}

function formatearMonto(monto) {
    if (monto === undefined || monto === null) {
        return undefined;
    }

    return new Intl.NumberFormat("es-AR").format(monto);
}

function generarContenidoMail(compra) {
    return plantillaCompilada({
        ...compra,
        fechaFormateada: formatearFecha(compra.fechaVisita),
        tiposPaseFormateados: formatearTiposPase(compra.tiposPase),
        montoFormateado: formatearMonto(compra.montoTotal)
    });
}

function validarEmailDestinatario(email) {
    if (email === null || email === undefined) {
        throw new Error("No se ha indicado un correo electrónico");
    }

    if (!email.includes("@")) {
        throw new Error("Formato de correo electrónico inválido");
    }
}

async function enviarMailConfirmacion(compra) {
    validarEmailDestinatario(compra.cliente.email);

    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT),
        secure: Number(process.env.SMTP_PORT) === 465,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });

    const html = generarContenidoMail(compra);

    const respuesta = await transporter.sendMail({
    from: process.env.SMTP_FROM,
    to: compra.cliente.email,
    subject: "Confirmación de compra - EcoHarmony Park",
    html,
    attachments: [
        {
            filename: "logo.png",
            path: path.join(__dirname, "logo.png"),
            cid: "logo-ecoharmony"
        }
    ]
});

    return respuesta;
}

module.exports = {
    generarContenidoMail,
    validarEmailDestinatario,
    enviarMailConfirmacion
};

